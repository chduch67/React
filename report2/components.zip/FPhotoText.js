import React from "react";
function FPhotoText(props) {
  const url = "img/" + props.image + ".jpg";
  const label = props.label;
  const boxStyle = {
    margin: "8px",
    padding: "40px",
  };
  return (
    <div style={boxStyle}>
      <img src={url} width="500" alt="weathermap" />
      <span>{label}</span>
    </div>
  );
}
export default FPhotoText;
