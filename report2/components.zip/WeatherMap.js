import React from 'react';
import FPhotoText from './FPhotoText';

const WeatherMap = () => {
  return (
    <div className="weather-map">
      <h2>날씨 지도</h2>
      {<FPhotoText image="weathermap" label = "전국 날씨 지도" />}
      <hr></hr>
    </div>
  );
}

export default WeatherMap;
