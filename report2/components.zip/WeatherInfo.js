import React from 'react';

const WeatherInfo = (props) => {
  const { data, location } = props;

  return (
    <div className="weatherinfo">
      <h2>현재 날씨 정보</h2>
      <p>위치: {location}</p>
      <p>온도: {data.temperature}도</p>
      <p>날씨 상태: {data.condition}</p>
      <hr></hr>
    </div>
  );
}

export default WeatherInfo;
