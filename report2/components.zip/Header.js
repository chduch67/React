import React from 'react';

const Header = () => {
  return (
    <header>
      <h1>날씨 정보</h1>
      <hr></hr>
    </header>
  );
}

export default Header;
