import React from 'react';

const WeatherForecast = () => {
  return (
    <div className="weather-forecast">
      <h2>날씨 예보</h2>
      {<p>2024년 4월 15일 날씨는 흐릴 예정입니다.</p>}
      <hr></hr>
    </div>
  );
}

export default WeatherForecast;
