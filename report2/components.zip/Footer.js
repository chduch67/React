import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>2024 날씨 정보</p>
    </footer>
  );
}

export default Footer;
